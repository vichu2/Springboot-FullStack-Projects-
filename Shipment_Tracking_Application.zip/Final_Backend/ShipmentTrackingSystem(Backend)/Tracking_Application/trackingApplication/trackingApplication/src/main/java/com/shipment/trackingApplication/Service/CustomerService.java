package com.shipment.trackingApplication.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shipment.trackingApplication.Entity.ShipmentDetail;
import com.shipment.trackingApplication.Repository.ShippingRepo;

@Service
public class CustomerService {

	@Autowired
	ShippingRepo shippingRepo;
	public ShipmentDetail getShippingInfo(String awb) {
		ShipmentDetail shipmentDetail=shippingRepo.findByAwb(awb);
	    
		return shipmentDetail; 
		
	}

}
