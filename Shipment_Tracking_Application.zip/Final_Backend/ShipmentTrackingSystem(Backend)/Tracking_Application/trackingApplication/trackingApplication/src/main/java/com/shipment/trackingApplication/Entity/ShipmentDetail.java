package com.shipment.trackingApplication.Entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;


@Entity
public class ShipmentDetail implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
	private int Id;
	private String date;
	private String awb;
	private String firstname;
	private String lastname;
	private String address; 
	private int mobilenumber;
	private String itemdetail;
	private String trackingstatus;
	private String amount;
	private String paymentdetail;
	
	
	
	public String getPaymentdetail() {
		return paymentdetail;
	}
	public void setPaymentdetail(String paymentdetail) {
		this.paymentdetail = paymentdetail;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getTrackingstatus() {
		return trackingstatus;
	}
	public void setTrackingstatus(String trackingstatus) {
		this.trackingstatus = trackingstatus;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}



	public String getDate() {
		return date;
	}



	public void setDate(String date) {
		this.date = date;
	}






	public String getAwb() {
		return awb;
	}



	public void setAwb(String awb) {
		this.awb = awb;
	}



	public String getFirstname() {
		return firstname;
	}



	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}



	public String getLastname() {
		return lastname;
	}



	public void setLastname(String lastname) {
		this.lastname = lastname;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public int getMobilenumber() {
		return mobilenumber;
	}



	public void setMobilenumber(int mobilenumber) {
		this.mobilenumber = mobilenumber;
	}



	public String getItemdetail() {
		return itemdetail;
	}



	public void setItemdetail(String itemdetail) {
		this.itemdetail = itemdetail;
	}



	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	@Override
	public String toString() {
		return "ShipmentDetail [Id=" + Id + ", date=" + date + ", awb=" + awb + ", firstname=" + firstname
				+ ", lastname=" + lastname + ", address=" + address + ", mobilenumber=" + mobilenumber + ", itemdetail="
				+ itemdetail + ", trackingstatus=" + trackingstatus + ", amount=" + amount + ", paymentdetail="
				+ paymentdetail + "]";
	}
	

	
}
