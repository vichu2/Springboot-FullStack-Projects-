package com.shipment.trackingApplication.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.shipment.trackingApplication.Entity.ShipmentDetail;

@Repository
public interface ShippingRepo extends JpaRepository<ShipmentDetail, Long>{

	@Query(value="select * from shipment_detail where awb=:awb", nativeQuery=true)
	ShipmentDetail findByAwb(String awb);
	
}
