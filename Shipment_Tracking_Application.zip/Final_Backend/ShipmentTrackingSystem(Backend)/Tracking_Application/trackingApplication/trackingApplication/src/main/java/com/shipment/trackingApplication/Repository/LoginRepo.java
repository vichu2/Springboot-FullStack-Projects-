package com.shipment.trackingApplication.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.shipment.trackingApplication.Entity.Login;

@Repository
public interface LoginRepo extends JpaRepository<Login, Integer>{
	
	@Query(value="select * from login where username=:userName and password=:password and role=:role", nativeQuery=true)
	Login findByUsernameAndPasswordAndRole(String userName,String password,String role);
}
