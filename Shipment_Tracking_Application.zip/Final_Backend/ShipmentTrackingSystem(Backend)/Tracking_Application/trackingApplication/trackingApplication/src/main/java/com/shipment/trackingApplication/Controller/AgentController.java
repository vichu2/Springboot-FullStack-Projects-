package com.shipment.trackingApplication.Controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.shipment.trackingApplication.Entity.Login;
import com.shipment.trackingApplication.Entity.ShipmentDetail;
import com.shipment.trackingApplication.Service.AgentService;
import com.shipment.trackingApplication.Service.LoginService;

@RestController
@RequestMapping("/agent")
@CrossOrigin("*")
public class AgentController {
	
	@Autowired
	LoginService loginService;
	
	@Autowired
	AgentService agentService;
	

	@PostMapping(value="/login", produces = "application/json")
	public ResponseEntity<?> authenticateLogin(@RequestBody Login login) 
	{
		 String status = loginService.authenticateLogin(login.getUsername(), login.getPassword(),"agent");
		 Map<String,String> statusmap = new HashMap<String,String>();
		 statusmap.put("status", status);
		
		 System.out.println(status);
		 return new ResponseEntity<>(statusmap,HttpStatus.OK);
	}
	
	@PostMapping(value="/status")
	public ResponseEntity<?> addStatus(@RequestBody HashMap<String,String> statusAwb) {
		String reportStatus  = agentService.saveTrackingStatus(statusAwb.get("status"), statusAwb.get("awb"));
		HashMap<String,String> statusMap = new HashMap<String,String>();
		statusMap.put("status", reportStatus);
		return new ResponseEntity<>(statusMap,HttpStatus.OK);
	}
	}
	 


