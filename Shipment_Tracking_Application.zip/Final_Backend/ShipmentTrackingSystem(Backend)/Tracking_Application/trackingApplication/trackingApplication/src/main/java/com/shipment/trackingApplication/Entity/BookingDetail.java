package com.shipment.trackingApplication.Entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import lombok.Getter;
import lombok.Setter;


@Entity
public class BookingDetail implements Serializable {
	
	@Id
	private String awb;
	private String date;
	private String firstname;
	private String lastname;
	private String address; 
	private int mobilenumber;
	private String itemdetail;
	
	
	
	public String getAwb() {
		return awb;
	}











	public void setAwb(String awb) {
		this.awb = awb;
	}











	public String getDate() {
		return date;
	}











	public void setDate(String date) {
		this.date = date;
	}











	public String getFirstname() {
		return firstname;
	}











	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}











	public String getLastname() {
		return lastname;
	}











	public void setLastname(String lastname) {
		this.lastname = lastname;
	}











	public String getAddress() {
		return address;
	}











	public void setAddress(String address) {
		this.address = address;
	}











	public int getMobilenumber() {
		return mobilenumber;
	}











	public void setMobilenumber(int mobilenumber) {
		this.mobilenumber = mobilenumber;
	}











	public String getItemdetail() {
		return itemdetail;
	}











	public void setItemdetail(String itemdetail) {
		this.itemdetail = itemdetail;
	}











	@Override
	public String toString() {
		return "BookingDetail [awb=" + awb + ", date=" + date + ", firstname=" + firstname + ", lastname=" + lastname
				+ ", address=" + address + ", mobilenumber=" + mobilenumber + ", itemdetail=" + itemdetail + "]";
	}











	
	
	}
