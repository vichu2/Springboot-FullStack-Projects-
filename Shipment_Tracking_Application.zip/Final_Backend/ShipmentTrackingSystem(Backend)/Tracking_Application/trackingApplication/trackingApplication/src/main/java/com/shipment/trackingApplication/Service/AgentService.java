package com.shipment.trackingApplication.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shipment.trackingApplication.Entity.ShipmentDetail;
import com.shipment.trackingApplication.Repository.ShippingRepo;

@Service
public class AgentService {

	@Autowired
	ShippingRepo shippingRepo;
	
	
	public String saveTrackingStatus(String trackingStatus,String awb) {
		ShipmentDetail shipmentDetail=shippingRepo.findByAwb(awb);
		if(shipmentDetail==null) {
			return "No Shipment detail for awb number";
			
		}
		shipmentDetail.setTrackingstatus(trackingStatus);
		shippingRepo.save(shipmentDetail);
		return "Tracking Status Saved";
	}
}
