package com.shipment.trackingApplication.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shipment.trackingApplication.Entity.BookingDetail;
import com.shipment.trackingApplication.Entity.ShipmentDetail;
import com.shipment.trackingApplication.Repository.ShippingRepo;

@Service
public class ShippingService {

	@Autowired
	ShippingRepo shippingRepo;
	
	public String saveShippingDetail(ShipmentDetail shipmentDetail)
	{
		shippingRepo.save(shipmentDetail);
		return "Shipment record saved";
		
	}
	
	
}
