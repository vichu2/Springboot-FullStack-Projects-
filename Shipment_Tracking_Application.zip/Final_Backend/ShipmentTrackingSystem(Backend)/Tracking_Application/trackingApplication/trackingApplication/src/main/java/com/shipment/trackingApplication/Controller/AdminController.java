package com.shipment.trackingApplication.Controller;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.shipment.trackingApplication.Entity.BookingDetail;
import com.shipment.trackingApplication.Entity.Login;
import com.shipment.trackingApplication.Entity.Report;
import com.shipment.trackingApplication.Entity.ShipmentDetail;
import com.shipment.trackingApplication.Service.BookingService;
import com.shipment.trackingApplication.Service.LoginService;
import com.shipment.trackingApplication.Service.ReportService;
import com.shipment.trackingApplication.Service.ShippingService;

@RestController
@RequestMapping("/admin") 
@CrossOrigin("*")
public class AdminController {
	
	@Autowired
	LoginService loginService;
	
	@Autowired
	BookingService bookingService;
	
	@Autowired
	ShippingService shippingService;

	@Autowired
	ReportService reportService;
	
	@PostMapping(value="/login", produces = "application/json")
	public ResponseEntity<?> authenticateLogin(@RequestBody Login login) 
	{
		 String status = loginService.authenticateLogin(login.getUsername(), login.getPassword(),"admin");
		 Map<String,String> statusmap = new HashMap<String,String>();
		 statusmap.put("status", status);
		 
		 System.out.println(status);
		 return new ResponseEntity<>(statusmap,HttpStatus.OK);
	}
	
	@PostMapping(value="/bookingDetail")
	public ResponseEntity<?> saveBookingInfo(@RequestBody BookingDetail bookingDetail)
	{
		String status = bookingService.saveBookingDetail(bookingDetail);
		 Map<String,String> statusmap = new HashMap<String,String>();
		 statusmap.put("status", status);
		 return new ResponseEntity<>(statusmap,HttpStatus.OK);
	
	}
	
	@PostMapping(value="/shippingDetail")
	public ResponseEntity<?> saveShippingInfo(@RequestBody ShipmentDetail shipmentDetail)
	{
		String status = shippingService.saveShippingDetail(shipmentDetail);
		Map<String,String> statusmap = new HashMap<String,String>();
		 statusmap.put("status", status);
		 return new ResponseEntity<>(statusmap,HttpStatus.OK);
	
	}
	
	
	@GetMapping(value="/report/{fromdate}/{todate}")
	public ResponseEntity<List<Report>> getReportInfo(@PathVariable String fromdate,@PathVariable String todate) throws ParseException {
		List<Report> report = reportService.getReportInfo(fromdate, todate);
		return new ResponseEntity<>(report,HttpStatus.OK);
	}

}
