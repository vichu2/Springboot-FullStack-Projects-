package com.shipment.trackingApplication.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.shipment.trackingApplication.Entity.ShipmentDetail;
import com.shipment.trackingApplication.Service.CustomerService;

@RestController
@RequestMapping(value="/customer")
@CrossOrigin("*")
public class CustomerController {

	@Autowired
	CustomerService customerService;
	
	@GetMapping(value="/tracking/{awb}")
	public ResponseEntity<List<ShipmentDetail>> getShippingInfo(@PathVariable String awb) {
		ShipmentDetail shipDetail = customerService.getShippingInfo(awb);
		List<ShipmentDetail> shipmentList = new ArrayList<ShipmentDetail>();
		shipmentList.add(shipDetail);
		return new ResponseEntity<>(shipmentList,HttpStatus.OK);
	
	}
	
}
