package com.shipment.trackingApplication.Service;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shipment.trackingApplication.Entity.BookingDetail;
import com.shipment.trackingApplication.Repository.BookingRepo;

@Service
public class BookingService {

	@Autowired
	BookingRepo bookingRepo;
	
	public String saveBookingDetail(BookingDetail bookingDetail)
	{
		String bookDate = null;
		if(bookingDetail.getDate()!=null && String.valueOf(bookingDetail.getMobilenumber())!=null) {
			bookDate = bookingDetail.getDate().replace("-", "");
			bookingDetail.setAwb(String.valueOf(bookingDetail.getMobilenumber())+bookDate);
		}
		 
		
		bookingRepo.save(bookingDetail);
		return "Booking record saved AWB #"+bookingDetail.getAwb();
		
	}
	
}
