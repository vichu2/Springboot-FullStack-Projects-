package com.shipment.trackingApplication.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shipment.trackingApplication.Entity.Login;
import com.shipment.trackingApplication.Repository.LoginRepo;

@Service
public class LoginService {
	
	@Autowired
	LoginRepo loginRepo;

	public String authenticateLogin(String username, String password, String role) {
		Login login = loginRepo.findByUsernameAndPasswordAndRole(username,password,role);
		if(login!=null) {
			return "success";
		}
		else {
			return "failure";
		}
	}
	

}
