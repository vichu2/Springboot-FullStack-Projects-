package com.shipment.trackingApplication.Entity;

import java.util.Date;

import javax.persistence.Id;

public class Report {

	@Id
	private String awb;
	private String bookingdate;
	private String bookingfirstname;
	private String bookinglastname;
	private String bookingaddress; 
	private int bookingmobilenumber;
	private String shippmentdate;
	private String shippmentfirstname;
	private String shippmentlastname;
	private String shippmentaddress; 
	private int shippmentmobilenumber;
	private String utr;
	private String invoice;
	
	public String getInvoice() {
		return invoice;
	}
	public void setInvoice(String invoice) {
		this.invoice = invoice;
	}
	public String getUtr() {
		return utr;
	}
	public void setUtr(String utr) {
		this.utr = utr;
	}

	public String getAwb() {
		return awb;
	}
	public void setAwb(String awb) {
		this.awb = awb;
	}
	public String getBookingfirstname() {
		return bookingfirstname;
	}
	public void setBookingfirstname(String bookingfirstname) {
		this.bookingfirstname = bookingfirstname;
	}
	public String getBookinglastname() {
		return bookinglastname;
	}
	public void setBookinglastname(String bookinglastname) {
		this.bookinglastname = bookinglastname;
	}
	public String getBookingaddress() {
		return bookingaddress;
	}
	public void setBookingaddress(String bookingaddress) {
		this.bookingaddress = bookingaddress;
	}
	public int getBookingmobilenumber() {
		return bookingmobilenumber;
	}
	public void setBookingmobilenumber(int bookingmobilenumber) {
		this.bookingmobilenumber = bookingmobilenumber;
	}
	
	public String getBookingdate() {
		return bookingdate;
	}
	public void setBookingdate(String bookingdate) {
		this.bookingdate = bookingdate;
	}
	public String getShippmentdate() {
		return shippmentdate;
	}
	public void setShippmentdate(String shippmentdate) {
		this.shippmentdate = shippmentdate;
	}
	public String getShippmentfirstname() {
		return shippmentfirstname;
	}
	public void setShippmentfirstname(String shippmentfirstname) {
		this.shippmentfirstname = shippmentfirstname;
	}
	public String getShippmentlastname() {
		return shippmentlastname;
	}
	public void setShippmentlastname(String shippmentlastname) {
		this.shippmentlastname = shippmentlastname;
	}
	public String getShippmentaddress() {
		return shippmentaddress;
	}
	public void setShippmentaddress(String shippmentaddress) {
		this.shippmentaddress = shippmentaddress;
	}
	public int getShippmentmobilenumber() {
		return shippmentmobilenumber;
	}
	public void setShippmentmobilenumber(int shippmentmobilenumber) {
		this.shippmentmobilenumber = shippmentmobilenumber;
	}
	
}
