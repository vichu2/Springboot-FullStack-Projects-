package com.shipment.trackingApplication.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shipment.trackingApplication.Entity.BookingDetail;
import com.shipment.trackingApplication.Entity.Report;
import com.shipment.trackingApplication.Entity.ShipmentDetail;
import com.shipment.trackingApplication.Repository.BookingRepo;
import com.shipment.trackingApplication.Repository.ShippingRepo;

@Service
public class ReportService {

	@Autowired
	BookingRepo bookingRepo;
	
	@Autowired
	ShippingRepo shippingRepo;
	
	@Autowired
	CustomerService customerService;
	
    public List<Report> getReportInfo(String fromDate,String toDate) throws ParseException {
	List<Report> report = new ArrayList<Report>();  
    Date datefrom=new SimpleDateFormat("dd-MM-yyyy").parse(fromDate);
    Date dateto = new SimpleDateFormat("dd-MM-yyyy").parse(toDate);
	List<BookingDetail> bookingDetails = bookingRepo.findAll();
	for(int i=0;i<bookingDetails.size();i++) {
		String date = bookingDetails.get(i).getDate();
		String pattern = "dd-MM-yyyy";
		SimpleDateFormat simpleFormat = new SimpleDateFormat(pattern);
		Date bookDate = simpleFormat.parse(date);
		if(bookDate.before(dateto)&&bookDate.after(datefrom)) {
			ShipmentDetail shipmentDetail = customerService.getShippingInfo(bookingDetails.get(i).getAwb());
			Report reportDetail = new Report();
			BookingDetail bookingDetail = bookingDetails.get(i);
			reportDetail.setAwb(shipmentDetail.getAwb());
			reportDetail.setBookingaddress(bookingDetail.getAddress());
			reportDetail.setBookingdate(bookingDetail.getDate());
			reportDetail.setBookingfirstname(bookingDetail.getFirstname());
			reportDetail.setBookinglastname(bookingDetail.getLastname());
			reportDetail.setBookingmobilenumber(bookingDetail.getMobilenumber());
			reportDetail.setShippmentaddress(shipmentDetail.getAddress());
			reportDetail.setShippmentdate(shipmentDetail.getDate());
			reportDetail.setShippmentfirstname(shipmentDetail.getFirstname());
			reportDetail.setShippmentlastname(shipmentDetail.getLastname());
			reportDetail.setShippmentmobilenumber(shipmentDetail.getMobilenumber());
			reportDetail.setUtr(shipmentDetail.getPaymentdetail());
		    reportDetail.setInvoice(shipmentDetail.getAmount());
			report.add(reportDetail);
		}
	}
	return report;
}
}
