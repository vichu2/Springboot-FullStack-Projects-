package com.shipment.trackingApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrackingApplicationTests {

	@Test
	void contextLoads() {
	}

}
